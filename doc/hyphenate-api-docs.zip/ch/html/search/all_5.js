var searchData=
[
  ['fetchchatroomblacklist',['fetchChatRoomBlackList',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_room_manager.html#a314857896294c00ffab070a94d87f740',1,'com::hyphenate::chat::EMChatRoomManager']]],
  ['fetchchatroomfromserver',['fetchChatRoomFromServer',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_room_manager.html#abe65c32b2b9c856a70501418bea203ce',1,'com.hyphenate.chat.EMChatRoomManager.fetchChatRoomFromServer(String roomId)'],['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_room_manager.html#a7576492c348f89ede237f3cc8ef0df86',1,'com.hyphenate.chat.EMChatRoomManager.fetchChatRoomFromServer(String roomId, boolean fetchMembers)']]],
  ['fetchchatroommembers',['fetchChatRoomMembers',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_room_manager.html#a1b8505dcb4b208dbfdc9c15cc078370d',1,'com::hyphenate::chat::EMChatRoomManager']]],
  ['fetchchatroommutelist',['fetchChatRoomMuteList',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_room_manager.html#adcc8a2cf7b46380e4efa050b4180a48a',1,'com::hyphenate::chat::EMChatRoomManager']]],
  ['fetchgroupblacklist',['fetchGroupBlackList',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_group_manager.html#a06a2d5b74dfa76cdc77f8b9f06edf059',1,'com::hyphenate::chat::EMGroupManager']]],
  ['fetchgroupmembers',['fetchGroupMembers',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_group_manager.html#aa7b80f6795a6273e83018abb124968e1',1,'com::hyphenate::chat::EMGroupManager']]],
  ['fetchgroupmutelist',['fetchGroupMuteList',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_group_manager.html#a6703905ab2cc1cf43f93df876a472bd4',1,'com::hyphenate::chat::EMGroupManager']]],
  ['fetchpublicchatroomsfromserver',['fetchPublicChatRoomsFromServer',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_room_manager.html#a14eff82a2de3497dbb953215ea1a7525',1,'com.hyphenate.chat.EMChatRoomManager.fetchPublicChatRoomsFromServer(int pageNum, int pageSize)'],['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_room_manager.html#a736a13beebf61bd5ccca2695a3fc9cd9',1,'com.hyphenate.chat.EMChatRoomManager.fetchPublicChatRoomsFromServer(int pageSize, String cursor)']]],
  ['file_5fdownload_5ffailed',['FILE_DOWNLOAD_FAILED',['../classcom_1_1hyphenate_1_1_e_m_error.html#a0ed081a4d17b21982d4427da8dff8ecb',1,'com::hyphenate::EMError']]],
  ['file_5finvalid',['FILE_INVALID',['../classcom_1_1hyphenate_1_1_e_m_error.html#a9a2d473a2ef681dc3d27a7b5a74cd006',1,'com::hyphenate::EMError']]],
  ['file_5fnot_5ffound',['FILE_NOT_FOUND',['../classcom_1_1hyphenate_1_1_e_m_error.html#a789d29bfbc18af52b711103af9e2a2d3',1,'com::hyphenate::EMError']]],
  ['file_5fupload_5ffailed',['FILE_UPLOAD_FAILED',['../classcom_1_1hyphenate_1_1_e_m_error.html#ad2311cd2907213d8df4d3292ef6aa296',1,'com::hyphenate::EMError']]]
];
