var searchData=
[
  ['blockchatroommembers',['blockChatroomMembers',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_room_manager.html#a3702fc4ccc4365b265fa97582caca695',1,'com::hyphenate::chat::EMChatRoomManager']]],
  ['blockgroupmessage',['blockGroupMessage',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_group_manager.html#a7a43485f1dc97d376ca5a748e49ed4f0',1,'com::hyphenate::chat::EMGroupManager']]],
  ['blockuser',['blockUser',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_group_manager.html#ac56c6e9f48ab00b665480fdf94b65804',1,'com::hyphenate::chat::EMGroupManager']]]
];
