var searchData=
[
  ['makevideocall',['makeVideoCall',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_call_manager.html#a3e49344c1ff527960e8978f2ba6858db',1,'com.hyphenate.chat.EMCallManager.makeVideoCall(String username)'],['../classcom_1_1hyphenate_1_1chat_1_1_e_m_call_manager.html#ad87e0433c0cd3bc71c86dfaea37bd6bc',1,'com.hyphenate.chat.EMCallManager.makeVideoCall(String username, String ext)']]],
  ['makevoicecall',['makeVoiceCall',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_call_manager.html#ab18d852e3ce41debf25142b69ff04cf5',1,'com.hyphenate.chat.EMCallManager.makeVoiceCall(String username)'],['../classcom_1_1hyphenate_1_1chat_1_1_e_m_call_manager.html#ac1865d6676dcae903ba5f8556bc1a413',1,'com.hyphenate.chat.EMCallManager.makeVoiceCall(String username, String ext)']]],
  ['markallconversationsasread',['markAllConversationsAsRead',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_manager.html#a4f7dbf5b36fadde636db34dfaa7fc41f',1,'com::hyphenate::chat::EMChatManager']]],
  ['markmessageasread',['markMessageAsRead',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_conversation.html#a9e542e10f41e0c7f84d9fac97d03b3fd',1,'com::hyphenate::chat::EMConversation']]],
  ['message_5fencryption_5ferror',['MESSAGE_ENCRYPTION_ERROR',['../classcom_1_1hyphenate_1_1_e_m_error.html#a6669df2ee9de1d0dc6231427a28b683a',1,'com::hyphenate::EMError']]],
  ['message_5finclude_5fillegal_5fcontent',['MESSAGE_INCLUDE_ILLEGAL_CONTENT',['../classcom_1_1hyphenate_1_1_e_m_error.html#a899d93b56c503bea06165d42ff2b0647',1,'com::hyphenate::EMError']]],
  ['message_5finvalid',['MESSAGE_INVALID',['../classcom_1_1hyphenate_1_1_e_m_error.html#afea45a5fbac3a4a40f3a2d24d092aecb',1,'com::hyphenate::EMError']]],
  ['message_5fsend_5ftraffic_5flimit',['MESSAGE_SEND_TRAFFIC_LIMIT',['../classcom_1_1hyphenate_1_1_e_m_error.html#a35cdce147efc8c840242791e6206d215',1,'com::hyphenate::EMError']]],
  ['messageencoder',['MessageEncoder',['../classcom_1_1hyphenate_1_1chat_1_1_message_encoder.html',1,'com::hyphenate::chat']]],
  ['msgtype2conversationtype',['msgType2ConversationType',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_conversation.html#a2af3c651b5402f316fea84d97bf5e1eb',1,'com::hyphenate::chat::EMConversation']]],
  ['mutechatroommembers',['muteChatRoomMembers',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_room_manager.html#a9085e1f9d988cccec5c8ecc7125babbf',1,'com::hyphenate::chat::EMChatRoomManager']]],
  ['mutegroupmembers',['muteGroupMembers',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_group_manager.html#a5a3abd57e52455ae68a1a5a5039862c3',1,'com::hyphenate::chat::EMGroupManager']]]
];
