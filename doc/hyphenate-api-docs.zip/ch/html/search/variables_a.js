var searchData=
[
  ['server_5fbusy',['SERVER_BUSY',['../classcom_1_1hyphenate_1_1_e_m_error.html#acb17152172d3af150b3906f06ae26ea2',1,'com::hyphenate::EMError']]],
  ['server_5fget_5fdnslist_5ffailed',['SERVER_GET_DNSLIST_FAILED',['../classcom_1_1hyphenate_1_1_e_m_error.html#a47bf219f00f9413678eef16120841186',1,'com::hyphenate::EMError']]],
  ['server_5fnot_5freachable',['SERVER_NOT_REACHABLE',['../classcom_1_1hyphenate_1_1_e_m_error.html#aa3d81fcde062618d9f81c1cb3e00ad11',1,'com::hyphenate::EMError']]],
  ['server_5fservice_5frestricted',['SERVER_SERVICE_RESTRICTED',['../classcom_1_1hyphenate_1_1_e_m_error.html#a8b258f5de26370c55891d52e72101411',1,'com::hyphenate::EMError']]],
  ['server_5ftimeout',['SERVER_TIMEOUT',['../classcom_1_1hyphenate_1_1_e_m_error.html#a0c2644b11ada9016f40e9be20d1116ad',1,'com::hyphenate::EMError']]],
  ['server_5funknown_5ferror',['SERVER_UNKNOWN_ERROR',['../classcom_1_1hyphenate_1_1_e_m_error.html#ae913315d6d8b7cf71c061e5440b87cb6',1,'com::hyphenate::EMError']]]
];
