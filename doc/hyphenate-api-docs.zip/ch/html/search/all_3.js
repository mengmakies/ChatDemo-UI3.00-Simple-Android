var searchData=
[
  ['declineapplication',['declineApplication',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_group_manager.html#a9bc0c85ab2dabd4352d1f1f65d6e2427',1,'com::hyphenate::chat::EMGroupManager']]],
  ['declineinvitation',['declineInvitation',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_contact_manager.html#a9ad0958d5b9de677cce7eaef4e0337fd',1,'com.hyphenate.chat.EMContactManager.declineInvitation()'],['../classcom_1_1hyphenate_1_1chat_1_1_e_m_group_manager.html#ae71c2cd6a0cd5f6a0d069f764ce958c1',1,'com.hyphenate.chat.EMGroupManager.declineInvitation()']]],
  ['decryptfile',['decryptFile',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_encrypt_utils.html#a5aaf1ba5fe1cf85f367be46066c3c453',1,'com::hyphenate::chat::EMEncryptUtils']]],
  ['deletecontact',['deleteContact',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_contact_manager.html#afc04729eb6d43609d05521c19c5450e0',1,'com.hyphenate.chat.EMContactManager.deleteContact(String username)'],['../classcom_1_1hyphenate_1_1chat_1_1_e_m_contact_manager.html#a747189d70df66c5e46ac95d6533a3113',1,'com.hyphenate.chat.EMContactManager.deleteContact(String username, boolean keepConversation)']]],
  ['deleteconversation',['deleteConversation',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_manager.html#ae00d3eb41e070546b6b7dc1c3e0750c3',1,'com::hyphenate::chat::EMChatManager']]],
  ['destroychatroom',['destroyChatRoom',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_room_manager.html#a3fd3cf731688c16383100825bc6ee827',1,'com::hyphenate::chat::EMChatRoomManager']]],
  ['destroygroup',['destroyGroup',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_group_manager.html#a860a34ecd342b1e15d3e6be7e31879be',1,'com::hyphenate::chat::EMGroupManager']]],
  ['direct',['direct',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_message.html#a63a9692bdcc9c7da476e42141c338c84',1,'com::hyphenate::chat::EMMessage']]],
  ['direct',['Direct',['../enumcom_1_1hyphenate_1_1chat_1_1_e_m_message_1_1_direct.html',1,'com::hyphenate::chat::EMMessage']]],
  ['disableofflinepush',['disableOfflinePush',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_push_manager.html#a5eefa3153a879aec8482805c9617dce8',1,'com::hyphenate::chat::EMPushManager']]],
  ['disconnected',['DISCONNECTED',['../enumcom_1_1hyphenate_1_1chat_1_1_e_m_call_state_change_listener_1_1_call_state.html#a9d270eeeddaedf1259c127d0e563f41b',1,'com::hyphenate::chat::EMCallStateChangeListener::CallState']]],
  ['downloadattachment',['downloadAttachment',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_manager.html#a1a938a579e8e5e07518d1e5008f9241d',1,'com::hyphenate::chat::EMChatManager']]],
  ['downloadfile',['downloadFile',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_manager.html#af39b20828a22e8a13ace18a8335ac50a',1,'com::hyphenate::chat::EMChatManager']]],
  ['downloadthumbnail',['downloadThumbnail',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_manager.html#a4c4f426c7cb00d44fee5d550a7eea5ce',1,'com::hyphenate::chat::EMChatManager']]]
];
